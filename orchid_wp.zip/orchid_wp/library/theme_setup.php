<?php
if ( ! isset( $content_width ) )
	$content_width = 1080;
	
add_action( 'after_setup_theme', 'orchid_theme_setup' );

if ( !function_exists('orchid_theme_setup') ) {

	function orchid_theme_setup() {
	
		// Register navigation menu
		register_nav_menus(
			array(
				'main-menu' => 'Primary Menu',
			)
		);
		
		// Localization support
		load_theme_textdomain('orchid_wp', get_template_directory() . '/lang');
		
		// Post formats
		add_theme_support( 'post-formats', array( 'gallery', 'video', 'audio' ) );
		
		// Featured image
		add_theme_support( 'post-thumbnails' );
		add_image_size( 'full-thumb', 1080, 0, true );
		add_image_size( 'slider-thumb', 1080, 530, true );
		add_image_size( 'misc-thumb', 520, 400, true );
		add_image_size( 'small-thumb', 100, 76, true );
        
		// Feed Links
		add_theme_support( 'automatic-feed-links' );
	
	}

}