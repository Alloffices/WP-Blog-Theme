<?php
if ( ! function_exists( 'orchid_load_scripts' ) ) {
    function orchid_load_scripts() {
        global $orchid_option;
    	// Register scripts and styles
        
    	wp_register_style('fontawesome-css', get_template_directory_uri() . '/css/font-awesome.min.css');
    	wp_register_style('bxslider-css', get_template_directory_uri() . '/css/jquery.bxslider.css', array('fontawesome-css'));
        wp_register_style('orchid-style', get_stylesheet_directory_uri() . '/style.css', array('bxslider-css'));
        wp_register_style('orchid-responsive', get_template_directory_uri() . '/css/responsive.css', array('orchid-style'));
    	
    	wp_register_script('slicknav', get_template_directory_uri() . '/js/jquery.slicknav.min.js', array( 'jquery' ), '', true);
    	wp_register_script('bxslider', get_template_directory_uri() . '/js/jquery.bxslider.min.js', array( 'jquery' ), '', true);
    	wp_register_script('fitvids', get_template_directory_uri() . '/js/fitvids.js', array( 'jquery' ), '', true);
    	wp_register_script('orchid-scripts', get_template_directory_uri() . '/js/orchid.js', array( 'jquery' ), '', true);
    	
    	// Enqueue scripts and styles
    	wp_enqueue_style('orchid-style');
    	wp_enqueue_style('fontawesome-css');
    	wp_enqueue_style('bxslider-css');
    	
    	if($orchid_option['orchid_responsive'] != 1) {
    	   wp_enqueue_style('orchid-responsive');
    	}
    	
    	// JS
    	wp_enqueue_script('slicknav');
    	wp_enqueue_script('bxslider');
    	wp_enqueue_script('fitvids');
    	wp_enqueue_script('orchid-scripts');
    	
    	if (is_singular() && get_option('thread_comments'))	wp_enqueue_script('comment-reply');
    	
    }
    add_action( 'wp_enqueue_scripts','orchid_load_scripts' );
}