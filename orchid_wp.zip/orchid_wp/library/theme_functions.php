<?php
if ( ! function_exists( 'orchid_comments' ) ) {
    function orchid_comments($comment, $args, $depth) {
    	$GLOBALS['comment'] = $comment;
    	
    	?>
    	<li <?php comment_class(); ?> id="comment-<?php comment_ID() ?>">
    		
    		<div class="thecomment">
    					
    			<div class="author-img">
    				<?php echo get_avatar($comment,$args['avatar_size']); ?>
    			</div>
    			
    			<div class="comment-text">
    				<span class="reply">
    					<?php comment_reply_link(array_merge( $args, array('reply_text' => esc_html__('Reply', 'orchid_wp'), 'depth' => $depth, 'max_depth' => $args['max_depth'])), $comment->comment_ID); ?>
    					<?php edit_comment_link(esc_html__('Edit', 'orchid_wp')); ?>
    				</span>
    				<h6 class="author"><?php echo get_comment_author_link(); ?></h6>
    				<span class="date"><?php printf(esc_html__('%1$s at %2$s', 'orchid_wp'), get_comment_date(),  get_comment_time()) ?></span>
    				<?php if ($comment->comment_approved == '0') : ?>
    					<em><i class="icon-info-sign"></i> <?php esc_html_e('Comment awaiting approval', 'orchid_wp'); ?></em>
    					<br />
    				<?php endif; ?>
    				<?php comment_text(); ?>
    			</div>
    					
    		</div>
    		
    		
    	</li>
    
    	<?php 
    }
}

if ( ! function_exists( 'orchid_pagination' ) ) {
    function orchid_pagination() {
    	
    	?>
    	
    	<div class="pagination">
    
    		<div class="older"><?php next_posts_link(esc_html__( 'Older Posts', 'orchid_wp').' <i class="fa fa-long-arrow-right"></i>'); ?></div>
    		<div class="newer"><?php previous_posts_link('<i class="fa fa-long-arrow-left"></i> '.esc_html__( 'Newer Posts', 'orchid_wp')); ?></div>
    		
    	</div>
    					
    	<?php
    	
    }
}

if ( ! function_exists( 'orchid_remove_more_link_scroll' ) ) {
    function orchid_remove_more_link_scroll( $link ) {
    	$link = preg_replace( '|#more-[0-9]+|', '', $link );
    	return $link;
    }
    add_filter( 'the_content_more_link', 'orchid_remove_more_link_scroll' );
}

if ( ! function_exists( 'orchid_wp_title' ) ) {
    function orchid_wp_title( $title, $sep ) {
    	global $paged, $page;
    
    	if ( is_feed() ) {
    		return $title;
    	}
    
    	// Add the site name.
    	$title .= get_bloginfo( 'name', 'display' );
    
    	// Add the site description for the home/front page.
    	$site_description = get_bloginfo( 'description', 'display' );
    	if ( $site_description && ( is_home() || is_front_page() ) ) {
    		$title = "$title $sep $site_description";
    	}
    
    	// Add a page number if necessary.
    	if ( ( $paged >= 2 || $page >= 2 ) && ! is_404() ) {
    		$title = "$title $sep " . sprintf( esc_html__( 'Page %s',  'orchid_wp' ), max( $paged, $page ) );
    	}
    
    	return $title;
    }
    add_filter( 'wp_title', 'orchid_wp_title', 10, 2 );
}

if ( ! function_exists( 'orchid_social_title' ) ) {
    function orchid_social_title( $title ) {
        $title = html_entity_decode( $title );
        $title = urlencode( $title );
        return $title;
    }
}

if ( ! function_exists( 'orchid_custom_excerpt_length' ) ) {
    function orchid_custom_excerpt_length( $length ) {
    	return 200;
    }
    add_filter( 'excerpt_length', 'orchid_custom_excerpt_length', 999 );
}

if ( ! function_exists( 'orchid_string_limit_words' ) ) {
    function orchid_string_limit_words($string, $word_limit)
    {
    	$words = explode(' ', $string, ($word_limit + 1));
    	
    	if(count($words) > $word_limit) {
    		array_pop($words);
    	}
    	
    	return implode(' ', $words);
    }
}