<?php

	/* Template Name: Page Sidebar with Slider */

?>
<?php get_header(); ?>
	
	<div class="container orchid-page-template orchid-sidebar-slider">
		
		<div id="content">
        
            <?php get_template_part('inc/templates/featured'); ?>
            
			<div id="main">
			
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				
					<?php get_template_part('content', 'page'); ?>
						
				<?php endwhile; ?>
				
				<?php endif; ?>
				
			</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>