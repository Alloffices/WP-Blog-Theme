<?php

/**
	ReduxFramework Config File
	For full documentation, please visit: https://github.com/ReduxFramework/ReduxFramework/wiki
**/

if ( !class_exists( "ReduxFramework" ) ) {
	return;
} 
if ( !class_exists( "Redux_Framework_config" ) ) {
	class Redux_Framework_config {

		public $args = array();
		public $sections = array();
		public $theme;
		public $ReduxFramework;

		public function __construct( ) {

			// Just for demo purposes. Not needed per say.
			$this->theme = wp_get_theme();

			// Set the default arguments
			$this->setArguments();
			
			// Set a few help tabs so you can see how it's done
			$this->setHelpTabs();

			// Create the sections and fields
			$this->setSections();
			
			if ( !isset( $this->args['opt_name'] ) ) { // No errors please
				return;
			}
			
			$this->ReduxFramework = new ReduxFramework($this->sections, $this->args);
			

			// If Redux is running as a plugin, this will remove the demo notice and links
			//add_action( 'redux/plugin/hooks', array( $this, 'remove_demo' ) );
			
			// Function to test the compiler hook and demo CSS output.
			//add_filter('redux/options/'.$this->args['opt_name'].'/compiler', array( $this, 'compiler_action' ), 10, 2); 
			// Above 10 is a priority, but 2 in necessary to include the dynamically generated CSS to be sent to the function.

			// Change the arguments after they've been declared, but before the panel is created
			//add_filter('redux/options/'.$this->args['opt_name'].'/args', array( $this, 'change_arguments' ) );
			
			// Change the default value of a field after it's been set, but before it's been used
			//add_filter('redux/options/'.$this->args['opt_name'].'/defaults', array( $this,'change_defaults' ) );

			// Dynamically add a section. Can be also used to modify sections/fields
			add_filter('redux/options/'.$this->args['opt_name'].'/sections', array( $this, 'dynamic_section' ) );

		}


		/**

			This is a test function that will let you see when the compiler hook occurs. 
			It only runs if a field	set with compiler=>true is changed.

		**/

		function compiler_action($options, $css) {

		}



		/**
		 
		 	Custom function for filtering the sections array. Good for child themes to override or add to the sections.
		 	Simply include this function in the child themes functions.php file.
		 
		 	NOTE: the defined constants for URLs, and directories will NOT be available at this point in a child theme,
		 	so you must use get_template_directory_uri() if you want to use any of the built in icons
		 
		 **/

		function dynamic_section($sections){
		    /*//$sections = array();
		    $sections[] = array(
		        'title' => esc_html__('Section via hook', 'orchid_wp'),
		        'desc' => esc_html__('<p class="description">This is a section created by adding a filter to the sections array. Can be used by child themes to add/remove sections from the options.</p>', 'orchid_wp'),
				'icon' => 'el-icon-paper-clip',
				    // Leave this as a blank section, no options just some intro text set above.
		        'fields' => array()
		    );*/

		    return $sections;
		}
		
		
		/**

			Filter hook for filtering the args. Good for child themes to override or add to the args array. Can also be used in other functions.

		**/
		
		function change_arguments($args){
		    //$args['dev_mode'] = false;
		    
		    return $args;
		}
			
		
		/**

			Filter hook for filtering the default value of any given field. Very useful in development mode.

		**/

		function change_defaults($defaults){
		    $defaults['str_replace'] = "Testing filter hook!";
		    
		    return $defaults;
		}


		// Remove the demo link and the notice of integrated demo from the redux-framework plugin
		function remove_demo() {
			
			// Used to hide the demo mode link from the plugin page. Only used when Redux is a plugin.
			if ( class_exists('ReduxFrameworkPlugin') ) {
				remove_filter( 'plugin_row_meta', array( ReduxFrameworkPlugin::get_instance(), 'plugin_meta_demo_mode_link'), null, 2 );
			}

			// Used to hide the activation notice informing users of the demo panel. Only used when Redux is a plugin.
			remove_action('admin_notices', array( ReduxFrameworkPlugin::get_instance(), 'admin_notices' ) );	

		}


		public function setSections() {

			/**
			 	Used within different fields. Simply examples. Search for ACTUAL DECLARATION for field examples
			 **/


			// Background Patterns Reader
			$sample_patterns_path = ReduxFramework::$_dir . '../sample/patterns/';
			$sample_patterns_url  = ReduxFramework::$_url . '../sample/patterns/';
			$sample_patterns      = array();

			ob_start();

			$ct = wp_get_theme();
			$this->theme = $ct;
			$item_name = $this->theme->get('Name'); 
			$tags = $this->theme->Tags;
			$screenshot = $this->theme->get_screenshot();
			$class = $screenshot ? 'has-screenshot' : '';

			$customize_title = sprintf( esc_html__( 'Customize &#8220;%s&#8221;','orchid_wp'), $this->theme->display('Name') );

			?>
			<div id="current-theme" class="<?php echo esc_attr( $class ); ?>">
				<?php if ( $screenshot ) : ?>
					<?php if ( current_user_can( 'edit_theme_options' ) ) : ?>
					<a href="<?php echo esc_url(wp_customize_url()); ?>" class="load-customize hide-if-no-customize" title="<?php echo esc_attr( $customize_title ); ?>">
						<img src="<?php echo esc_url( $screenshot ); ?>" alt="<?php esc_attr_e( 'Current theme preview', 'orchid_wp'); ?>" />
					</a>
					<?php endif; ?>
					<img class="hide-if-customize" src="<?php echo esc_url( $screenshot ); ?>" alt="<?php esc_attr_e( 'Current theme preview', 'orchid_wp'); ?>" />
				<?php endif; ?>

				<h4>
					<?php echo (esc_attr($this->theme->display('Name'))); ?>
				</h4>

				<div>
					<ul class="theme-info">
						<li><?php printf( esc_html__('By %s','orchid_wp'), $this->theme->display('Author') ); ?></li>
						<li><?php printf( esc_html__('Version %s','orchid_wp'), $this->theme->display('Version') ); ?></li>
						<li><?php echo '<strong>'.esc_html__('Tags', 'orchid_wp').':</strong> '; ?><?php printf( $this->theme->display('Tags') ); ?></li>
					</ul>
					<p class="theme-description"><?php echo esc_attr($this->theme->display('Description')); ?></p>
					<?php if ( $this->theme->parent() ) {
						printf( ' <p class="howto">' . esc_html__( 'This <a href="%1$s">child theme</a> requires its parent theme, %2$s.', 'orchid_wp') . '</p>',
							esc_html__( 'http://codex.wordpress.org/Child_Themes','orchid_wp'),
							$this->theme->parent()->display( 'Name' ) );
					} ?>
					
				</div>

			</div>

			<?php
			$item_info = ob_get_contents();
			    
			ob_end_clean();

			$sampleHTML = '';

                $this->sections[] = array(
    				'icon' => 'el-icon-tasks',
    				'title' => esc_html__('Site Layout', 'orchid_wp'),
    				'fields' => array(
                        array(
                            'id'       => 'orchid_responsive',
                            'type'     => 'switch', 
                            'title'    => esc_html__('Disable Responsive Layout', 'orchid_wp'),
                            'default'  => false,
                        ),
                        array(
                            'id'       => 'orchid_home_layout',
                            'type'     => 'radio',
                            'title'    => esc_html__('Homepage Layout', 'orchid_wp'),
                            'options'  => array(
                                'full'   => 'Only Large Post Layout',
        						'grid'  => 'Only Grid Post Layout',
        						'full_grid'  => '1 Large Post + Grid Layout',
        						'list'  => 'Classic Blog Layout',
        						'full_list'  => '1 Large Post + Classic Blog Layout',
                            ),
                            'default' => 'grid'
                        ),
                        array(
                            'id'       => 'orchid_archive_layout',
                            'type'     => 'radio',
                            'title'    => esc_html__('Archive Layout', 'orchid_wp'),
                            'options'  => array(
                                'full'   => 'Only Large Post Layout',
        						'grid'  => 'Only Grid Post Layout',
        						'full_grid'  => '1 Large Post + Grid Layout',
        						'list'  => 'Classic Blog Layout',
        						'full_list'  => '1 Large Post + Classic Blog Layout',
                            ),
                            'default' => 'full_list'
                        ),
                        array(
                            'id'       => 'orchid_sidebar_homepage',
                            'type'     => 'switch', 
                            'title'    => esc_html__('Homepage Sidebar', 'orchid_wp'),
                            'default'  => true,
                        ),
                        array(
                            'id'       => 'orchid_sidebar_post',
                            'type'     => 'switch', 
                            'title'    => esc_html__('Post Sidebar', 'orchid_wp'),
                            'default'  => true,
                        ),
                        array(
                            'id'       => 'orchid_sidebar_archive',
                            'type'     => 'switch', 
                            'title'    => esc_html__('Archive Sidebar', 'orchid_wp'),
                            'default'  => true,
                        ),
                        array(
                            'id'       => 'orchid_post_summary',
                            'type'     => 'radio',
                            'title'    => esc_html__('Post Summary Type', 'orchid_wp'),
                            'options'  => array(
                                'full'   => 'Use Read More Tag',
                                'excerpt'  => 'Use Excerpt',
                            ),
                            'default' => 'excerpt'
                        ),
    				)
    			);
                $this->sections[] = array(
    				'icon' => 'el-icon-credit-card',
    				'title' => esc_html__('Header Settings', 'orchid_wp'),
    				'fields' => array(
                        array(
    						'id'=>'orchid_logo',
    						'type' => 'media', 
    						'url'=> true,
    						'title' => esc_html__('Site logo', 'orchid_wp'),
    						'desc' => esc_html__('Upload Header logo of your site', 'orchid_wp'),
                            'placeholder' => esc_html__('No media selected','orchid_wp'),
                            'default'  => '',
						),
                        array(
                            'id'        => 'orchid_header_padding_top',
                            'type'      => 'slider',
                            'title'     => esc_html__('Top Header Padding', 'orchid_wp'),
                            "default"   => 56,
                            "min"       => 1,
                            "step"      => 1,
                            "max"       => 200,
                            'display_value' => 'text'
                        ),
                        array(
                            'id'        => 'orchid_header_padding_bottom',
                            'type'      => 'slider',
                            'title'     => esc_html__('Bottom Header Padding', 'orchid_wp'),
                            "default"   => 56,
                            "min"       => 1,
                            "step"      => 1,
                            "max"       => 200,
                            'display_value' => 'text'
                        ),
    				)
    			);
                $this->sections[] = array(
    				'icon' => 'el-icon-credit-card',
    				'title' => esc_html__('Top Bar Settings', 'orchid_wp'),
    				'fields' => array(
                        array(
                            'id'       => 'orchid_topbar_social_check',
                            'type'     => 'switch', 
                            'title'    => esc_html__('Top Bar Social Icons', 'orchid_wp'),
                            'default'  => true,
                        ),
                        array(
                            'id'       => 'orchid_topbar_search_check',
                            'type'     => 'switch', 
                            'title'    => esc_html__('Top Bar Search', 'orchid_wp'),
                            'default'  => true,
                        ),
    				)
    			);
                $this->sections[] = array(
    				'icon' => 'el-icon-credit-card',
    				'title' => esc_html__('Featured Slider Settings', 'orchid_wp'),
    				'fields' => array(
                        array(
                            'id'       => 'orchid_featured_slider',
                            'type'     => 'switch', 
                            'title'    => esc_html__('Featured Slider', 'orchid_wp'),
                            'default'  => true,
                        ),
                        array(
                            'id' => 'orchid_featured_cat',  
                            'type' => 'select',
                            'data' => 'categories',
                            'multi' => true,
                            'title' => esc_html__('Select Category', 'orchid_wp'),
                            'desc' => esc_html__('Select category/categories for the featured slider', 'orchid_wp'),
                            'default'  => '',
                        ),
                        array(
                            'id'       => 'orchid_featured_id',
                            'type'     => 'text',
                            'title'    => esc_html__('Select Featured Post IDs', 'orchid_wp'),
                            'desc'     => esc_html__('Separate each ID with a comma. These IDs will override the featured category option above.', 'orchid_wp'),
                            'default'  => '',
                        ),
                        array(
                            'id'        => 'orchid_featured_slider_slides',
                            'type'      => 'slider',
                            'title'     => esc_html__('Number of Posts that will be shown in the Slider', 'orchid_wp'),
                            "default"   => 5,
                            "min"       => 1,
                            "step"      => 1,
                            "max"       => 50,
                            'display_value' => 'text'
                        ),
                        array(
                            'id'       => 'orchid_featured_hide_cat',
                            'type'     => 'switch', 
                            'title'    => esc_html__('Display Category', 'orchid_wp'),
                            'default'  => true,
                        ),
    				)
    			);
                $this->sections[] = array(
    				'icon' => 'el-icon-credit-card',
    				'title' => esc_html__('Promo Boxes Settings', 'orchid_wp'),
    				'fields' => array(
                        array(
                            'id'       => 'orchid_promo',
                            'type'     => 'switch', 
                            'title'    => esc_html__('Promo Boxes', 'orchid_wp'),
                            'default'  => false,
                        ),
                        array(
                            'id'       => 'orchid_promo1_title',
                            'type'     => 'text',
                            'title'    => esc_html__('Promo Box #1 Title', 'orchid_wp'),
                            'default'  => '',
                        ),
                        array(
                            'id'       => 'orchid_promo1_url',
                            'type'     => 'text',
                            'title'    => esc_html__('Destination URL #1', 'orchid_wp'),
                            'default'  => '',
                        ),
                        array(
    						'id'=>'orchid_promo1_image',
    						'type' => 'media', 
    						'url'=> true,
    						'title' => esc_html__('Promo Box #1 Image', 'orchid_wp'),
                            'placeholder' => esc_html__('No media selected','orchid_wp'),
                            'default'  => '',
						),
                        array(
                            'id'       => 'orchid_promo2_title',
                            'type'     => 'text',
                            'title'    => esc_html__('Promo Box #2 Title', 'orchid_wp'),
                            'default'  => '',
                        ),
                        array(
                            'id'       => 'orchid_promo2_url',
                            'type'     => 'text',
                            'title'    => esc_html__('Destination URL #2', 'orchid_wp'),
                            'default'  => '',
                        ),
                        array(
    						'id'=>'orchid_promo2_image',
    						'type' => 'media', 
    						'url'=> true,
    						'title' => esc_html__('Promo Box #2 Image', 'orchid_wp'),
                            'placeholder' => esc_html__('No media selected','orchid_wp'),
                            'default'  => '',
						),
                        array(
                            'id'       => 'orchid_promo3_title',
                            'type'     => 'text',
                            'title'    => esc_html__('Promo Box #3 Title', 'orchid_wp'),
                            'default'  => '',
                        ),
                        array(
                            'id'       => 'orchid_promo3_url',
                            'type'     => 'text',
                            'title'    => esc_html__('Destination URL #3', 'orchid_wp'),
                            'default'  => '',
                        ),
                        array(
    						'id'=>'orchid_promo3_image',
    						'type' => 'media', 
    						'url'=> true,
    						'title' => esc_html__('Promo Box #3 Image', 'orchid_wp'),
                            'placeholder' => esc_html__('No media selected','orchid_wp'),
                            'default'  => '',
						),
    				)
    			);
                $this->sections[] = array(
    				'icon' => 'el-icon-credit-card',
    				'title' => esc_html__('Post Settings', 'orchid_wp'),
    				'fields' => array(
                        array(
                            'id'       => 'orchid_post_thumb',
                            'type'     => 'switch', 
                            'title'    => esc_html__('Featured Image of Post', 'orchid_wp'),
                            'default'  => true,
                        ),
                        array(
                            'id'       => 'orchid_post_cat',
                            'type'     => 'switch', 
                            'title'    => esc_html__('Post Category', 'orchid_wp'),
                            'default'  => true,
                        ),
                        array(
                            'id'       => 'orchid_post_date',
                            'type'     => 'switch', 
                            'title'    => esc_html__('Post Date', 'orchid_wp'),
                            'default'  => true,
                        ),
                        array(
                            'id'       => 'orchid_post_comment_link',
                            'type'     => 'switch', 
                            'title'    => esc_html__('Post Comment Link', 'orchid_wp'),
                            'default'  => true,
                        ),
                        array(
                            'id'       => 'orchid_post_share_author',
                            'type'     => 'switch', 
                            'title'    => esc_html__('Post Author Name', 'orchid_wp'),
                            'default'  => true,
                        ),
                        array(
                            'id'       => 'orchid_post_tags',
                            'type'     => 'switch', 
                            'title'    => esc_html__('Post Tags', 'orchid_wp'),
                            'default'  => true,
                        ),
                        array(
                            'id'       => 'orchid_post_share',
                            'type'     => 'switch', 
                            'title'    => esc_html__('Post Share Buttons', 'orchid_wp'),
                            'default'  => true,
                        ),
                        array(
                            'id'       => 'orchid_post_author',
                            'type'     => 'switch', 
                            'title'    => esc_html__('Post Author Box', 'orchid_wp'),
                            'default'  => true,
                        ),
                        array(
                            'id'       => 'orchid_post_related',
                            'type'     => 'switch', 
                            'title'    => esc_html__('Related Posts Box', 'orchid_wp'),
                            'default'  => true,
                        ),
                        array(
                            'id'       => 'orchid_post_pagination',
                            'type'     => 'switch', 
                            'title'    => esc_html__('Post Pagination', 'orchid_wp'),
                            'default'  => true,
                        ),
    				)
    			);
                $this->sections[] = array(
    				'icon' => 'el-icon-credit-card',
    				'title' => esc_html__('Page Settings', 'orchid_wp'),
    				'fields' => array(
                        array(
                            'id'       => 'orchid_page_share',
                            'type'     => 'switch', 
                            'title'    => esc_html__('Share Buttons', 'orchid_wp'),
                            'default'  => true,
                        ),
    				)
    			);
                $this->sections[] = array(
    				'icon' => 'el-icon-credit-card',
    				'title' => esc_html__('Social Media Settings', 'orchid_wp'),
    				'fields' => array(
                        array(
                            'id'       => 'orchid_facebook',
                            'type'     => 'text',
                            'title'    => esc_html__('Facebook Username', 'orchid_wp'),
                            'default'  => '',
                        ),
                        array(
                            'id'       => 'orchid_twitter',
                            'type'     => 'text',
                            'title'    => esc_html__('Twitter Username', 'orchid_wp'),
                            'default'  => '',
                        ),
                        array(
                            'id'       => 'orchid_instagram',
                            'type'     => 'text',
                            'title'    => esc_html__('Instagram Username', 'orchid_wp'),
                            'default'  => '',
                        ),
                        array(
                            'id'       => 'orchid_pinterest',
                            'type'     => 'text',
                            'title'    => esc_html__('Pinterest Username', 'orchid_wp'),
                            'default'  => '',
                        ),
                        array(
                            'id'       => 'orchid_bloglovin',
                            'type'     => 'text',
                            'title'    => esc_html__('Bloglovin Username', 'orchid_wp'),
                            'default'  => '',
                        ),
                        array(
                            'id'       => 'orchid_google',
                            'type'     => 'text',
                            'title'    => esc_html__('Google Plus Username', 'orchid_wp'),
                            'default'  => '',
                        ),
                        array(
                            'id'       => 'orchid_tumblr',
                            'type'     => 'text',
                            'title'    => esc_html__('Tumblr Username', 'orchid_wp'),
                            'default'  => '',
                        ),
                        array(
                            'id'       => 'orchid_youtube',
                            'type'     => 'text',
                            'title'    => esc_html__('Youtube Username', 'orchid_wp'),
                            'default'  => '',
                        ),
                        array(
                            'id'       => 'orchid_dribbble',
                            'type'     => 'text',
                            'title'    => esc_html__('Dribbble Username', 'orchid_wp'),
                            'default'  => '',
                        ),
                        array(
                            'id'       => 'orchid_soundcloud',
                            'type'     => 'text',
                            'title'    => esc_html__('Soundcloud Username', 'orchid_wp'),
                            'default'  => '',
                        ),
                        array(
                            'id'       => 'orchid_vimeo',
                            'type'     => 'text',
                            'title'    => esc_html__('Vimeo Username', 'orchid_wp'),
                            'default'  => '',
                        ),
                        array(
                            'id'       => 'orchid_linkedin',
                            'type'     => 'text',
                            'title'    => esc_html__('Linkedin (Full URL)', 'orchid_wp'),
                            'default'  => '',
                        ),
                        array(
                            'id'       => 'orchid_rss',
                            'type'     => 'text',
                            'title'    => esc_html__('RSS Link Username', 'orchid_wp'),
                            'default'  => '',
                        ),
    				)
    			);
                $this->sections[] = array(
    				'icon' => 'el-icon-credit-card',
    				'title' => esc_html__('Footer Settings', 'orchid_wp'),
    				'fields' => array(
                        array(
                            'id'       => 'orchid_footer_copyright',
                            'type'     => 'text', 
                            'title'    => esc_html__('Footer Copyright Text', 'orchid_wp'),
                            'default'  => '',
                        ),
                        array(
                            'id'       => 'orchid_footer_share',
                            'type'     => 'switch', 
                            'title'    => esc_html__('Footer Social Links', 'orchid_wp'),
                            'default'  => true,
                        ),
    				)
    			);
                $this->sections[] = array(
    				'icon' => 'el-icon-credit-card',
    				'title' => esc_html__('Color: Top Bar', 'orchid_wp'),
    				'fields' => array(
                        array(
                            'id'       => 'orchid_topbar_bg',
                            'type'     => 'color',
                            'title'    => esc_html__('Top Bar Background', 'orchid_wp'),
                            'default'  => '#fff',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_topbar_nav_color',
                            'type'     => 'color',
                            'title'    => esc_html__('Top Bar Menu Text Color', 'orchid_wp'),
                            'default'  => '#000',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_topbar_nav_color_hover',
                            'type'     => 'color',
                            'title'    => esc_html__('Top Bar Menu Text Hover Color', 'orchid_wp'),
                            'default'  => '#F0A48D',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_drop_bg',
                            'type'     => 'color',
                            'title'    => esc_html__('Dropdown Background', 'orchid_wp'),
                            'default'  => '#000',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_drop_border',
                            'type'     => 'color',
                            'title'    => esc_html__('Dropdown Border Color', 'orchid_wp'),
                            'default'  => '#333333',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_drop_text_color',
                            'type'     => 'color',
                            'title'    => esc_html__('Dropdown Text Color', 'orchid_wp'),
                            'default'  => '#fff',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_drop_text_hover_bg',
                            'type'     => 'color',
                            'title'    => esc_html__('Dropdown Text Hover Background', 'orchid_wp'),
                            'default'  => '#333333',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_drop_text_hover_color',
                            'type'     => 'color',
                            'title'    => esc_html__('Dropdown Text Hover Color', 'orchid_wp'),
                            'default'  => '#fff',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_topbar_social_color',
                            'type'     => 'color',
                            'title'    => esc_html__('Top Bar Social Icons', 'orchid_wp'),
                            'default'  => '#444',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_topbar_social_color_hover',
                            'type'     => 'color',
                            'title'    => esc_html__('Top Bar Social Icons Hover', 'orchid_wp'),
                            'default'  => '#F0A48D',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_topbar_search_magnify',
                            'type'     => 'color',
                            'title'    => esc_html__('Top Bar Search Icon Color', 'orchid_wp'),
                            'default'  => '#444',
                            'validate' => 'color',
                        ),
    				)
    			);
                $this->sections[] = array(
    				'icon' => 'el-icon-credit-card',
    				'title' => esc_html__('Color: Mobile Menu', 'orchid_wp'),
    				'fields' => array(
                        array(
                            'id'       => 'orchid_mobile_bg',
                            'type'     => 'color',
                            'title'    => esc_html__('Mobile Menu Background Color', 'orchid_wp'),
                            'default'  => '#000',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_mobile_text',
                            'type'     => 'color',
                            'title'    => esc_html__('Mobile Menu Link Color', 'orchid_wp'),
                            'default'  => '#fff',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_mobile_icon',
                            'type'     => 'color',
                            'title'    => esc_html__('Mobile Menu Toggle Icon Color', 'orchid_wp'),
                            'default'  => '#000',
                            'validate' => 'color',
                        ),
    				)
    			);
                $this->sections[] = array(
    				'icon' => 'el-icon-credit-card',
    				'title' => esc_html__('Color: Sidebar', 'orchid_wp'),
    				'fields' => array(
                        array(
                            'id'       => 'orchid_sidebar_title_border',
                            'type'     => 'color',
                            'title'    => esc_html__('Sidebar Widget Title Border', 'orchid_wp'),
                            'default'  => '#000',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_sidebar_title_text',
                            'type'     => 'color',
                            'title'    => esc_html__('Sidebar Widget Title Text Color', 'orchid_wp'),
                            'default'  => '#000',
                            'validate' => 'color',
                        ),                      
                        array(
                            'id'       => 'orchid_sidebar_social_icon',
                            'type'     => 'color',
                            'title'    => esc_html__('Sidebar Social Icon Color', 'orchid_wp'),
                            'default'  => '#666',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_sidebar_social_icon_hover',
                            'type'     => 'color',
                            'title'    => esc_html__('Sidebar Social Icon Hover Color', 'orchid_wp'),
                            'default'  => '#f0a48d',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_sidebar_newsletter_bg',
                            'type'     => 'color',
                            'title'    => esc_html__('Mailchimp Widget Background Color', 'orchid_wp'),
                            'default'  => '#f2f2f2',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_sidebar_newsletter_text',
                            'type'     => 'color',
                            'title'    => esc_html__('Mailchimp Widget Text Color', 'orchid_wp'),
                            'default'  => '#444',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_sidebar_newsletter_button_bg',
                            'type'     => 'color',
                            'title'    => esc_html__('Mailchimp Widget Button Background Color', 'orchid_wp'),
                            'default'  => '#f0a48d',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_sidebar_newsletter_button_text',
                            'type'     => 'color',
                            'title'    => esc_html__('Mailchimp Widget Button Text Color', 'orchid_wp'),
                            'default'  => '#fff',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_sidebar_newsletter_button_bg_hover',
                            'type'     => 'color',
                            'title'    => esc_html__('Mailchimp Widget Button Background Hover Color', 'orchid_wp'),
                            'default'  => '#000',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_sidebar_newsletter_button_text_hover',
                            'type'     => 'color',
                            'title'    => esc_html__('Mailchimp Widget Button Text Hover Color', 'orchid_wp'),
                            'default'  => '#fff',
                            'validate' => 'color',
                        ),
    				)
    			);
                $this->sections[] = array(
    				'icon' => 'el-icon-credit-card',
    				'title' => esc_html__('Color: Footer', 'orchid_wp'),
    				'fields' => array(
                        array(
                            'id'       => 'orchid_footer_bg',
                            'type'     => 'color',
                            'title'    => esc_html__('Footer Background Color', 'orchid_wp'),
                            'default'  => '#000',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_footer_social',
                            'type'     => 'color',
                            'title'    => esc_html__('Footer Social Icon Color', 'orchid_wp'),
                            'default'  => '#fff',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_footer_social_hover',
                            'type'     => 'color',
                            'title'    => esc_html__('Footer Social Icon Hover Color', 'orchid_wp'),
                            'default'  => '#F0A48D',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_footer_copyright_color',
                            'type'     => 'color',
                            'title'    => esc_html__('Footer Copyright Text Color', 'orchid_wp'),
                            'default'  => '#fff',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_footer_copyright_link',
                            'type'     => 'color',
                            'title'    => esc_html__('Footer Copyright Link Color', 'orchid_wp'),
                            'default'  => '#F0A48D',
                            'validate' => 'color',
                        ),
    				)
    			);
                $this->sections[] = array(
    				'icon' => 'el-icon-credit-card',
    				'title' => esc_html__('Color: Post', 'orchid_wp'),
    				'fields' => array(
                        array(
                            'id'       => 'orchid_post_title',
                            'type'     => 'color',
                            'title'    => esc_html__('Post Title Color', 'orchid_wp'),
                            'default'  => '#000',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_post_text',
                            'type'     => 'color',
                            'title'    => esc_html__('Post Text Color', 'orchid_wp'),
                            'default'  => '#000',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_post_h',
                            'type'     => 'color',
                            'title'    => esc_html__('Post H1-H6 Color', 'orchid_wp'),
                            'default'  => '#000',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_post_readmore_text',
                            'type'     => 'color',
                            'title'    => esc_html__('Read More Text Color', 'orchid_wp'),
                            'default'  => '#F0A48D',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_post_readmore_text_hover',
                            'type'     => 'color',
                            'title'    => esc_html__('Read More Text Hover Color', 'orchid_wp'),
                            'default'  => '#F0A48D',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_post_share_color',
                            'type'     => 'color',
                            'title'    => esc_html__('Post Share Link Color', 'orchid_wp'),
                            'default'  => '#fff',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_post_share_bg_color',
                            'type'     => 'color',
                            'title'    => esc_html__('Post Share Background Color', 'orchid_wp'),
                            'default'  => '#000',
                            'validate' => 'color',
                        ),
    				)
    			);
                $this->sections[] = array(
    				'icon' => 'el-icon-credit-card',
    				'title' => esc_html__('Color: Category', 'orchid_wp'),
    				'fields' => array(
                        array(
                            'id'       => 'orchid_cat_color',
                            'type'     => 'color',
                            'title'    => esc_html__('Category Color', 'orchid_wp'),
                            'default'  => '#fff',
                            'validate' => 'color',
                        ),
                        array(
                            'id'       => 'orchid_cat_bg_color',
                            'type'     => 'color',
                            'title'    => esc_html__('Category Background Color', 'orchid_wp'),
                            'default'  => '#F0A48D',
                            'validate' => 'color',
                        ),
    				)
    			);
                $this->sections[] = array(
    				'icon' => 'el-icon-credit-card',
    				'title' => esc_html__('Color: Link', 'orchid_wp'),
    				'fields' => array(
                        array(
                            'id'       => 'orchid_a_color',
                            'type'     => 'color',
                            'title'    => esc_html__('Link Color', 'orchid_wp'),
                            'default'  => '#F0A48D',
                            'validate' => 'color',
                        ),
    				)
    			);
                $this->sections[] = array(
            		'icon'    => ' el-icon-font',
            		'title'   => esc_html__('Typography', 'orchid_wp'),
            		'fields'  => array(
                        array(
            				'id'=>'orchid-header-font',
            				'type' => 'typography', 
                            'output' => array('#nav-wrapper .menu li a, .slicknav_nav ul, .slicknav_nav li a'),
            				'title' => esc_html__('Navigation font', 'orchid_wp'),
            				//'compiler'=>true, // Use if you want to hook in your own CSS compiler
            				'google'=>true, // Disable google fonts. Won't work if you haven't defined your google api key
            				//'font-style'=>false, // Includes font-style and weight. Can use font-style or font-weight to declare
            				//'subsets'=>false, // Only appears if google is true and subsets not set to false
            				'font-size'=>false,
            				'line-height'=>false,
            				//'word-spacing'=>true, // Defaults to false
            				//'letter-spacing'=>true, // Defaults to false
            				'color'=>false,
            				//'preview'=>false, // Disable the previewer
            				'all_styles' => true, // Enable all Google Font style/weight variations to be added to the page
            				'units'=>'px', // Defaults to px
                            'text-align' => false,
            				'subtitle'=> esc_html__('Font options for menu, category title and module title', 'orchid_wp'),
            				'default'=> array( 
            					'font-weight'=>'700', 
            					'font-family'=>'Lato', 
            					'google' => true,
            				    ),
                        ),
                        array(
            				'id'=>'orchid-post-meta-font',
            				'type' => 'typography', 
                            'output' => array('.post-meta, .post-meta > span, .date, .post-date'),
            				'title' => esc_html__('Post Meta font', 'orchid_wp'),
            				//'compiler'=>true, // Use if you want to hook in your own CSS compiler
            				'google'=>true, // Disable google fonts. Won't work if you haven't defined your google api key
            				//'font-style'=>false, // Includes font-style and weight. Can use font-style or font-weight to declare
            				//'subsets'=>false, // Only appears if google is true and subsets not set to false
            				'font-size'=>false,
            				'line-height'=>false,
            				//'word-spacing'=>true, // Defaults to false
            				//'letter-spacing'=>true, // Defaults to false
            				'color'=>false,
            				//'preview'=>false, // Disable the previewer
            				'all_styles' => true, // Enable all Google Font style/weight variations to be added to the page
            				'units'=>'px', // Defaults to px
                            'text-align' => false,
            				'subtitle'=> esc_html__('Font options for title of posts', 'orchid_wp'),
            				'default'=> array( 
            					'font-weight'=>'400', 
            					'font-family'=>'Lora', 
            					'google' => true,
            				    ),
                        ),
                        array(
            				'id'=>'orchid-title-link-font',
            				'type' => 'typography', 
                            'output' => array('h1, h2, h3, h4, h5, h5, h6, 
                            .read-more-btn, .post-share .post-share-comments, .about-title, #footer-social a, .more-link, 
                            .post-comments span.reply a, .widget .tagcloud a, .pagination a, 
                            .post-tags a, .slicknav_nav a, .post-pagination a'),
            				'title' => esc_html__('Post Title and Links font', 'orchid_wp'),
            				//'compiler'=>true, // Use if you want to hook in your own CSS compiler
            				'google'=>true, // Disable google fonts. Won't work if you haven't defined your google api key
            				//'font-style'=>false, // Includes font-style and weight. Can use font-style or font-weight to declare
            				//'subsets'=>false, // Only appears if google is true and subsets not set to false
            				'font-size'=>false,
            				'line-height'=>false,
            				//'word-spacing'=>true, // Defaults to false
            				//'letter-spacing'=>true, // Defaults to false
            				'color'=>false,
            				//'preview'=>false, // Disable the previewer
            				'all_styles' => true, // Enable all Google Font style/weight variations to be added to the page
            				'units'=>'px', // Defaults to px
                            'text-align' => false,
            				'subtitle'=> esc_html__('Font options for the Post Titles and Links', 'orchid_wp'),
            				'default'=> array( 
            					'font-weight'=>'700', 
            					'font-family'=>'Lato', 
            					'google' => true,
            				    ),
                        ),
                 
                        array(
            				'id'=>'orchid-body-font',
            				'type' => 'typography',
                            'output' => array('body, input, textarea'), 
            				'title' => esc_html__('Text font', 'orchid_wp'),
            				//'compiler'=>true, // Use if you want to hook in your own CSS compiler
            				'google'=>true, // Disable google fonts. Won't work if you haven't defined your google api key
            				//'font-style'=>false, // Includes font-style and weight. Can use font-style or font-weight to declare
            				//'subsets'=>false, // Only appears if google is true and subsets not set to false
            				'font-size'=>false,
            				'line-height'=>false,
            				//'word-spacing'=>true, // Defaults to false
            				//'letter-spacing'=>true, // Defaults to false
            				'color'=>false,
            				//'preview'=>false, // Disable the previewer
            				'all_styles' => true, // Enable all Google Font style/weight variations to be added to the page
            				'units'=>'px', // Defaults to px
                            'text-align' => false,
            				'subtitle'=> esc_html__('Font options for text body', 'orchid_wp'),
            				'default'=> array(
            					'font-weight'=>'400', 
            					'font-family'=>'PT Serif', 
            					'google' => true,
                            ),
            			),
                    ),
                );
                $this->sections[] = array(
    				'icon' => 'el-icon-css',
    				'title' => esc_html__('Custom CSS', 'orchid_wp'),
    				'fields' => array(
                        array(
    						'id'=>'orchid-custom-css',
    						'type' => 'ace_editor',
    						'title' => esc_html__('CSS Code', 'orchid_wp'), 
    						'subtitle' => esc_html__('Paste your CSS code here.', 'orchid_wp'),
    						'mode' => 'css',
    			            'theme' => 'chrome',
       			            'default' => "",
    					),                                           	
    				)
    			);				
					

			$theme_info = '<div class="redux-framework-section-desc">';
			$theme_info .= '<p class="redux-framework-theme-data description theme-uri">'.esc_html__('<strong>Theme URL:</strong> ', 'orchid_wp').'<a href="'.$this->theme->get('ThemeURI').'" target="_blank">'.$this->theme->get('ThemeURI').'</a></p>';
			$theme_info .= '<p class="redux-framework-theme-data description theme-author">'.esc_html__('<strong>Author:</strong> ', 'orchid_wp').$this->theme->get('Author').'</p>';
			$theme_info .= '<p class="redux-framework-theme-data description theme-version">'.esc_html__('<strong>Version:</strong> ', 'orchid_wp').$this->theme->get('Version').'</p>';
			$theme_info .= '<p class="redux-framework-theme-data description theme-description">'.$this->theme->get('Description').'</p>';
			$tabs = $this->theme->get('Tags');
			if ( !empty( $tabs ) ) {
				$theme_info .= '<p class="redux-framework-theme-data description theme-tags">'.esc_html__('<strong>Tags:</strong> ', 'orchid_wp').implode(', ', $tabs ).'</p>';	
			}
			$theme_info .= '</div>';

			$this->sections[] = array(
				'type' => 'divide',
			);

			$this->sections[] = array(
				'icon' => 'el-icon-info-sign',
				'title' => esc_html__('Theme Information', 'orchid_wp'),
				'fields' => array(
					array(
						'id'=>'raw_new_info',
						'type' => 'raw',
						'content' => $item_info,
						)
					),   
				);
		}	

		public function setHelpTabs() {

			/*// Custom page help tabs, displayed using the help API. Tabs are shown in order of definition.
			$this->args['help_tabs'][] = array(
			    'id' => 'redux-opts-1',
			    'title' => esc_html__('Theme Information 1', 'orchid_wp'),
			    'content' => esc_html__('<p>This is the tab content, HTML is allowed.</p>', 'orchid_wp')
			);

			$this->args['help_tabs'][] = array(
			    'id' => 'redux-opts-2',
			    'title' => esc_html__('Theme Information 2', 'orchid_wp'),
			    'content' => esc_html__('<p>This is the tab content, HTML is allowed.</p>', 'orchid_wp')
			);

			// Set the help sidebar
			$this->args['help_sidebar'] = esc_html__('<p>This is the sidebar content, HTML is allowed.</p>', 'orchid_wp');*/

		}


		/**
			
			All the possible arguments for Redux.
			For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments

		 **/
		public function setArguments() {
			
			$theme = wp_get_theme(); // For use with some settings. Not necessary.

			$this->args = array(
	            
	            // TYPICAL -> Change these values as you need/desire
				'opt_name'          	=> 'orchid_option', // This is where your data is stored in the database and also becomes your global variable name.
				'display_name'			=> $theme->get('Name'), // Name that appears at the top of your panel
				'display_version'		=> $theme->get('Version'), // Version that appears at the top of your panel
				'menu_type'          	=> 'menu', //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
				'allow_sub_menu'     	=> true, // Show the sections below the admin menu item or not
				'menu_title'			=> esc_html__( 'Theme Options', 'orchid_wp'),
	            'page'		 	 		=> esc_html__( 'Theme Options', 'orchid_wp'),
	            'google_api_key'   	 	=> 'AIzaSyBdxbxgVuwQcnN5xCZhFDSpouweO-yJtxw', // Must be defined to add google fonts to the typography module
	            'global_variable'    	=> '', // Set a different name for your global variable other than the opt_name
	            'dev_mode'           	=> false, // Show the time the page took to load, etc
	            'customizer'         	=> true, // Enable basic customizer support

	            // OPTIONAL -> Give you extra features
	            'page_priority'      	=> null, // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
	            'page_parent'        	=> 'themes.php', // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
	            'page_permissions'   	=> 'manage_options', // Permissions needed to access the options panel.
	            'menu_icon'          	=> '', // Specify a custom URL to an icon
	            'last_tab'           	=> '', // Force your panel to always open to a specific tab (by id)
	            'page_icon'          	=> 'icon-themes', // Icon displayed in the admin panel next to your menu_title
	            'page_slug'          	=> '_options', // Page slug used to denote the panel
	            'save_defaults'      	=> true, // On load save the defaults to DB before user clicks save or not
	            'default_show'       	=> false, // If true, shows the default value next to each field that is not the default value.
	            'default_mark'       	=> '', // What to print by the field's title if the value shown is default. Suggested: *


	            // CAREFUL -> These options are for advanced use only
	            'transient_time' 	 	=> 60 * MINUTE_IN_SECONDS,
	            'output'            	=> true, // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
	            'output_tag'            	=> true, // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
	            //'domain'             	=> 'orchid_wp', // Translation domain key. Don't change this unless you want to retranslate all of Redux.
	            //'footer_credit'      	=> '', // Disable the footer credit of Redux. Please leave if you can help it.
	            

	            // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
	            'database'           	=> '', // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
	            
	        
	            'show_import_export' 	=> true, // REMOVE
	            'system_info'        	=> false, // REMOVE
	            
	            'help_tabs'          	=> array(),
	            'help_sidebar'       	=> '', // esc_html__( '', $this->args['domain'] );            
				);


			// SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.		
			$this->args['share_icons'][] = array(
			    'url' => 'https://github.com/ReduxFramework/ReduxFramework',
			    'title' => 'Visit us on GitHub', 
			    'icon' => 'el-icon-github'
			    // 'img' => '', // You can use icon OR img. IMG needs to be a full URL.
			);		
			$this->args['share_icons'][] = array(
			    'url' => 'https://www.facebook.com/pages/Redux-Framework/243141545850368',
			    'title' => 'Like us on Facebook', 
			    'icon' => 'el-icon-facebook'
			);
			$this->args['share_icons'][] = array(
			    'url' => 'http://twitter.com/reduxframework',
			    'title' => 'Follow us on Twitter', 
			    'icon' => 'el-icon-twitter'
			);
			$this->args['share_icons'][] = array(
			    'url' => 'http://www.linkedin.com/company/redux-framework',
			    'title' => 'Find us on LinkedIn', 
			    'icon' => 'el-icon-linkedin'
			);

			
	 
			// Panel Intro text -> before the form
			if (!isset($this->args['global_variable']) || $this->args['global_variable'] !== false ) {
				if (!empty($this->args['global_variable'])) {
					$v = $this->args['global_variable'];
				} else {
					$v = str_replace("-", "_", $this->args['opt_name']);
				}
				$this->args['intro_text'] = '';
			} else {
				$this->args['intro_text'] = '';
			}

			// Add content after the form.
			$this->args['footer_text'] = '' ;

		}
	}
	new Redux_Framework_config();

}


/** 

	Custom function for the callback referenced above

 */
if ( !function_exists( 'redux_my_custom_field' ) ):
	function redux_my_custom_field($field, $value) {
	    print_r($field);
	    print_r($value);
	}
endif;

/**
 
	Custom function for the callback validation referenced above

**/
if ( !function_exists( 'redux_validate_callback_function' ) ):
	function redux_validate_callback_function($field, $value, $existing_value) {
	    $error = false;
	    $value =  'just testing';
	    /*
	    do your validation
	    
	    if(something) {
	        $value = $value;
	    } elseif(something else) {
	        $error = true;
	        $value = $existing_value;
	        $field['msg'] = 'your custom error message';
	    }
	    */
	    
	    $return['value'] = $value;
	    if($error == true) {
	        $return['error'] = $field;
	    }
	    return $return;
	}
endif;
