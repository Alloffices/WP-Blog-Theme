<?php
//////////////////////////////////////////////////////////////////
// Customizer - Add CSS
//////////////////////////////////////////////////////////////////
function orchid_customizer_css() {
    global $orchid_option;
    $orchid_custom_css = '';
    $orchid_header_padding_top = esc_attr($orchid_option['orchid_header_padding_top']);
    $orchid_header_padding_bottom = esc_attr($orchid_option['orchid_header_padding_bottom']);
    if($orchid_option['orchid_topbar_bg']) :
        $orchid_topbar_bg = esc_attr($orchid_option['orchid_topbar_bg']);
    endif;
    
    if($orchid_option['orchid_topbar_nav_color']):
        $orchid_topbar_nav_color = esc_attr($orchid_option['orchid_topbar_nav_color']);
    endif;
    

    
    $orchid_topbar_nav_color_hover = esc_attr($orchid_option['orchid_topbar_nav_color_hover']);
    $orchid_drop_bg = esc_attr($orchid_option['orchid_drop_bg']);
    
    if($orchid_option['orchid_drop_border']) :
        $orchid_drop_border = esc_attr($orchid_option['orchid_drop_border']);
        $orchid_drop_text_color = esc_attr($orchid_option['orchid_drop_text_color']);
    endif;
    
    $orchid_drop_text_hover_color = esc_attr($orchid_option['orchid_drop_text_hover_color']);
    $orchid_drop_text_hover_bg = esc_attr($orchid_option['orchid_drop_text_hover_bg']);
    $orchid_mobile_bg = esc_attr($orchid_option['orchid_mobile_bg']);
	$orchid_mobile_text = esc_attr($orchid_option['orchid_mobile_text']); 
    $orchid_mobile_icon = esc_attr($orchid_option['orchid_mobile_icon']);
    $orchid_topbar_social_color = esc_attr($orchid_option['orchid_topbar_social_color']);
    $orchid_topbar_social_color_hover = esc_attr($orchid_option['orchid_topbar_social_color_hover']);
    $orchid_topbar_search_magnify = esc_attr($orchid_option['orchid_topbar_search_magnify']);
    $orchid_sidebar_title_border = esc_attr($orchid_option['orchid_sidebar_title_border']);
    $orchid_sidebar_title_text = esc_attr($orchid_option['orchid_sidebar_title_text']);
    $orchid_sidebar_social_icon = esc_attr($orchid_option['orchid_sidebar_social_icon']);
    $orchid_sidebar_social_icon_hover = esc_attr($orchid_option['orchid_sidebar_social_icon_hover']);
    $orchid_footer_bg = esc_attr($orchid_option['orchid_footer_bg']);
    $orchid_footer_social = esc_attr($orchid_option['orchid_footer_social']);
    $orchid_footer_social_hover = esc_attr($orchid_option['orchid_footer_social_hover']);
    $orchid_footer_copyright_color = esc_attr($orchid_option['orchid_footer_copyright_color']);
    $orchid_footer_copyright_link = esc_attr($orchid_option['orchid_footer_copyright_link']);
    $orchid_post_title = esc_attr($orchid_option['orchid_post_title']);
    $orchid_post_text = esc_attr($orchid_option['orchid_post_text']);
    $orchid_post_h = esc_attr($orchid_option['orchid_post_h']);
    $orchid_post_readmore_text = esc_attr($orchid_option['orchid_post_readmore_text']);
    $orchid_post_readmore_text_hover = esc_attr($orchid_option['orchid_post_readmore_text_hover']);
    $orchid_post_share_color = esc_attr($orchid_option['orchid_post_share_color']);
    $orchid_post_share_bg_color = esc_attr($orchid_option['orchid_post_share_bg_color']);
    $orchid_sidebar_newsletter_bg = esc_attr($orchid_option['orchid_sidebar_newsletter_bg']);
    $orchid_sidebar_newsletter_text = esc_attr($orchid_option['orchid_sidebar_newsletter_text']);
    $orchid_sidebar_newsletter_button_bg = esc_attr($orchid_option['orchid_sidebar_newsletter_button_bg']);
    $orchid_sidebar_newsletter_button_text = esc_attr($orchid_option['orchid_sidebar_newsletter_button_text']);
    $orchid_sidebar_newsletter_button_bg_hover = esc_attr($orchid_option['orchid_sidebar_newsletter_button_bg_hover']);
    $orchid_sidebar_newsletter_button_text_hover = esc_attr($orchid_option['orchid_sidebar_newsletter_button_text_hover']);
    $orchid_cat_color = esc_attr($orchid_option['orchid_cat_color']);
    $orchid_cat_bg_color = esc_attr($orchid_option['orchid_cat_bg_color']);
    $orchid_a_color = esc_attr($orchid_option['orchid_a_color']);
    
    
		$orchid_custom_css .= "#logo { padding-top:{$orchid_header_padding_top}px; padding-bottom:{$orchid_header_padding_bottom}px; }";
        
        if($orchid_option['orchid_topbar_bg']) :
            $orchid_custom_css .= "#top-bar, .slicknav_menu { background:{$orchid_topbar_bg}; }";
        endif;
        
        if($orchid_option['orchid_topbar_nav_color']):
            $orchid_custom_css .= "#nav-wrapper .menu li a{ color:{$orchid_topbar_nav_color}; }";
        endif;
        
        $orchid_custom_css .= "#nav-wrapper .menu li a:hover {  color:{$orchid_topbar_nav_color_hover}; }";
        $orchid_custom_css .= "#nav-wrapper .menu .sub-menu, #nav-wrapper .menu .children { background: {$orchid_drop_bg}; }";
        
        if($orchid_option['orchid_drop_border']) :
            $orchid_custom_css .= "#nav-wrapper ul.menu ul a, #nav-wrapper .menu ul ul a { border-top: 1px solid {$orchid_drop_border}; color:{$orchid_drop_text_color}; }";
        endif;
        
        $orchid_custom_css .= "#nav-wrapper ul.menu ul a:hover, #nav-wrapper .menu ul ul a:hover { color: {$orchid_drop_text_hover_color}; background:{$orchid_drop_text_hover_bg}; }";
        $orchid_custom_css .= ".slicknav_nav { background:{$orchid_mobile_bg} }";
        $orchid_custom_css .= ".slicknav_nav a { color:$orchid_mobile_text; }";
        $orchid_custom_css .= ".slicknav_menu .slicknav_icon-bar { background-color:{$orchid_mobile_icon}; }";
        $orchid_custom_css .= "#top-social a { color:{$orchid_topbar_social_color}; }";
        $orchid_custom_css .= "#top-social a:hover { color:{$orchid_topbar_social_color_hover}; }";
        $orchid_custom_css .= "#top-search i { color:{$orchid_topbar_search_magnify}; }";
        $orchid_custom_css .= ".widget-title { border-color: {$orchid_sidebar_title_border}; color: {$orchid_sidebar_title_text};}";
        $orchid_custom_css .= ".widget-title:after { border-top-color:{$orchid_sidebar_title_border}; }";
        $orchid_custom_css .= ".social-widget a { color:{$orchid_sidebar_social_icon}; }";
        $orchid_custom_css .= ".social-widget a:hover { color:{$orchid_sidebar_social_icon_hover}; }";
        $orchid_custom_css .= "#footer { background:{$orchid_footer_bg}; }";
        $orchid_custom_css .= "#footer-social a { color:{$orchid_footer_social}; }";
        $orchid_custom_css .= "#footer-social a:hover { color:{$orchid_footer_social_hover}; }";
        $orchid_custom_css .= ".copyright { color:{$orchid_footer_copyright_color}; }";
        $orchid_custom_css .= ".copyright a { color:{$orchid_footer_copyright_link}; }";
        $orchid_custom_css .= ".post-header h2 a, .post-header h1 { color:{$orchid_post_title}; }";
        $orchid_custom_css .= ".post-entry p { color:{$orchid_post_text}; }";
        $orchid_custom_css .= ".post-entry h1, .post-entry h2, .post-entry h3, .post-entry h4, .post-entry h5, .post-entry h6 { color:{$orchid_post_h}; }";
        $orchid_custom_css .= ".more-link { color:{$orchid_post_readmore_text}; }";
        $orchid_custom_css .= "a.more-link:hover { color:{$orchid_post_readmore_text_hover}; }";
        $orchid_custom_css .= ".post-share-box.share-buttons a { color:{$orchid_post_share_color}; }";
        $orchid_custom_css .= ".post-share-box.share-buttons a { background-color:{$orchid_post_share_bg_color}; }";
        $orchid_custom_css .= ".mc4wp-form { background:{$orchid_sidebar_newsletter_bg}; }";
        $orchid_custom_css .= ".mc4wp-form label { color:{$orchid_sidebar_newsletter_text}; }";
        $orchid_custom_css .= ".mc4wp-form button, .mc4wp-form input[type=button], .mc4wp-form input[type=submit] { background:{$orchid_sidebar_newsletter_button_bg}; color:{$orchid_sidebar_newsletter_button_text}; }";
        $orchid_custom_css .= ".mc4wp-form button:hover, .mc4wp-form input[type=button]:hover, .mc4wp-form input[type=submit]:hover { background:{$orchid_sidebar_newsletter_button_bg_hover}; color:{$orchid_sidebar_newsletter_button_text_hover}; }";
        $orchid_custom_css .= ".post-header .cat a { color:{$orchid_cat_color}; }";
        $orchid_custom_css .= ".post-header .cat a, .feat-overlay .cat a { background-color:{$orchid_cat_bg_color}; }";
        $orchid_custom_css .= "a { color:{$orchid_a_color}; }";
        $orchid_custom_css .= ".sticky .post-header h2, .sticky .post-header h1 { color:{$orchid_a_color}; }";
	
    if($orchid_option['orchid-custom-css']) :
		$orchid_custom_css .= esc_attr($orchid_option['orchid-custom-css']);
	endif;
    
    wp_add_inline_style( 'orchid-style', $orchid_custom_css );
}
add_action( 'wp_enqueue_scripts', 'orchid_customizer_css' );