<form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
		<input type="text" placeholder="<?php esc_html_e('Search and hit enter...', 'orchid_wp'); ?>" name="s" id="s" />
</form>