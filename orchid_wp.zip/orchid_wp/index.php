<?php get_header(); ?>
	<?php global $orchid_option;?>
	<div class="container">
		
		<div id="content">
  
			<?php if($orchid_option['orchid_featured_slider'] != '0') : ?>
				<?php get_template_part('inc/templates/featured'); ?>
			<?php endif; ?>
		
			<?php if($orchid_option['orchid_promo'] == 1) : ?>
				<?php get_template_part('inc/templates/promo'); ?>
			<?php endif; ?>
			<div id="main" <?php if($orchid_option['orchid_sidebar_homepage'] == '0') : ?>class="fullwidth"<?php endif; ?>>
				
				<?php if($orchid_option['orchid_home_layout'] == 'grid' || $orchid_option['orchid_home_layout'] == 'full_grid') : ?><ul class="orchid-grid-wrap"><?php endif; ?>
				
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
					
					<?php if($orchid_option['orchid_home_layout'] == 'grid') : ?>
					
						<?php get_template_part('content', 'grid'); ?>
					
					<?php elseif($orchid_option['orchid_home_layout'] == 'list') : ?>
					
						<?php get_template_part('content', 'list'); ?>
						
					<?php elseif($orchid_option['orchid_home_layout'] == 'full_list') : ?>
					
						<?php if( $wp_query->current_post == 0 && !is_paged() ) : ?>
							<?php get_template_part('content'); ?>
						<?php else : ?>
							<?php get_template_part('content', 'list'); ?>
						<?php endif; ?>
					
					<?php elseif($orchid_option['orchid_home_layout'] == 'full_grid') : ?>
					
						<?php if( $wp_query->current_post == 0 && !is_paged() ) : ?>
							<?php get_template_part('content'); ?>
						<?php else : ?>
							<?php get_template_part('content', 'grid'); ?>
						<?php endif; ?>
					
					<?php else : ?>
						
						<?php get_template_part('content'); ?>
						
					<?php endif; ?>	
						
				<?php endwhile; ?>
				
				<?php if($orchid_option['orchid_home_layout'] == 'grid' || $orchid_option['orchid_home_layout'] == 'full_grid') : ?></ul><?php endif; ?>
				
					<?php orchid_pagination(); ?>
				
				<?php endif; ?>
			
			</div>

<?php if($orchid_option['orchid_sidebar_homepage'] == '0') : else : ?><?php get_sidebar(); ?><?php endif; ?>
<?php get_footer(); ?>