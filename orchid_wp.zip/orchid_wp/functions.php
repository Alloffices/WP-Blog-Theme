<?php
function orchid_removeDemoModeLink() { // Be sure to rename this function to something more unique
    if ( class_exists('ReduxFrameworkPlugin') ) {
        remove_filter( 'plugin_row_meta', array( ReduxFrameworkPlugin::get_instance(), 'plugin_metalinks'), null, 2 );
    }
    if ( class_exists('ReduxFrameworkPlugin') ) {
        remove_action('admin_notices', array( ReduxFrameworkPlugin::get_instance(), 'admin_notices' ) );    
    }
}
add_action('init', 'orchid_removeDemoModeLink');
/**-------------------------------------------------------------------------------------------------------------------------
 * remove redux admin page
 */
if ( ! function_exists( 'orchid_remove_redux_page' ) ) {
	function orchid_remove_redux_page() {
		remove_submenu_page( 'tools.php', 'redux-about' );
	}
	add_action( 'admin_menu', 'orchid_remove_redux_page', 12 );
}

add_theme_support('title-tag');

include_once( get_template_directory() . '/library/theme_setup.php' );
include_once( get_template_directory() . '/library/enqueue_script.php' );

// Theme Options
include_once(get_template_directory() . '/options/dynamic_style.php');
require_once( get_template_directory() . '/options/theme-option.php' );

// Widgets
include_once(get_template_directory() . '/inc/widgets/about_widget.php');
include_once(get_template_directory() . '/inc/widgets/social_widget.php');
include_once(get_template_directory() . '/inc/widgets/post_widget.php');
include_once(get_template_directory() . '/inc/widgets/facebook_widget.php');

//register sidebar
include_once( get_template_directory() . '/library/register_sidebar.php' );

// Theme Function
include_once( get_template_directory() . '/library/theme_functions.php' );

// TGM
include_once( get_template_directory() . '/library/tgm_setup.php' );