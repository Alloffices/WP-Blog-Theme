<?php get_header(); ?>
	
	<div class="container">
		
		<div id="content">
		
			<div class="error-page">
				
				<h1><?php esc_html_e('404', 'orchid_wp');?></h1>
				<p><?php esc_html_e( 'Oops! The page you were looking for was not found. Perhaps searching can help.', 'orchid_wp' ); ?></p>
				<?php get_search_form(); ?>
				
			</div>
			
            
<?php get_footer(); ?>