<?php global $orchid_option;?>
<div class="featured-slider <?php if(!$orchid_option['orchid_promo']) : ?>nopromo<?php endif; ?>">
			
	<div class="sideslides">
	
		<div class="bxslider">
		
			<?php
				if (isset($orchid_option['orchid_featured_cat'])) {
				    $featured_cat = $orchid_option['orchid_featured_cat'];
                }else {
                    $featured_cat = '';
                }
                if (isset($orchid_option['orchid_featured_id'])) {
				    $get_featured_posts = $orchid_option['orchid_featured_id'];
                }else {
                    $get_featured_posts = '';
                }
                if (isset($orchid_option['orchid_featured_slider_slides'])) {
				    $number = $orchid_option['orchid_featured_slider_slides'];
                }else {
                    $number = 3;
                }
				
                if (($featured_cat == null) || ($featured_cat == '') || (count($featured_cat) == 0)) {
                    $featured_cat = 0;
                }
				if($get_featured_posts) {
					$featured_posts = explode(',', $get_featured_posts);
					$args = array( 'showposts' => $number, 'post_type' => array('post', 'page'), 'post__in' => $featured_posts, 'orderby' => 'post__in' );
				} else {
					$args = array( 'cat' => $featured_cat, 'showposts' => $number );
				}
				
			?>
			
			<?php $feat_query = new WP_Query( $args ); ?>
		
			<?php if ($feat_query->have_posts()) : while ($feat_query->have_posts()) : $feat_query->the_post(); ?>
			
			<?php 
				
				// Get slider image
				if(get_post_meta( get_the_ID(), 'meta-image', true )) :
				
					$feat_image = get_post_meta( get_the_ID(), 'meta-image', true );
					
				else :
				
					if(has_post_thumbnail()) {
						$get_feat_image = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'full' );
						$feat_image = $get_feat_image[0];
					} else {
						$feat_image = get_template_directory_uri() . '/images/slider-default.jpg';
					}
				
				endif;
			
			?>
			
			<div class="feat-item" style="background-image:url(<?php echo esc_url($feat_image); ?>)">
				
				<div class="feat-overlay">
					<div class="feat-inner">
						<?php if($orchid_option['orchid_featured_hide_cat']) : ?>
						<span class="cat"><?php the_category(' '); ?></span>
						<?php endif; ?>
						<h2><a href="<?php echo get_permalink(); ?>"><?php the_title(); ?></a></h2>
						<a href="<?php echo get_permalink(); ?>" class="read-more-btn"><?php esc_html_e( 'Read More', 'orchid_wp' ); ?></a>
					</div>
				</div>
				
			</div>
			
			<?php endwhile; endif; ?>
			
		</div>
	
	</div>
	
</div>