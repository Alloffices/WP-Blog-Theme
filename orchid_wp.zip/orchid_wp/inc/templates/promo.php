<?php global $orchid_option;?>
<div class="orchid-promo-section">
	
	<?php if($orchid_option['orchid_promo1_title'] || $orchid_option['orchid_promo1_image']) : ?>
	<div class="promo-item" style="background-image:url(<?php if($orchid_option['orchid_promo1_image']['url']) { echo esc_url($orchid_option['orchid_promo1_image']['url']); } else { echo get_template_directory_uri() . '/images/slider-default.jpg'; } ?>)">
		<?php if($orchid_option['orchid_promo1_url']) : ?><a href="<?php echo esc_url($orchid_option['orchid_promo1_url']); ?>" class="promo-link"></a><?php endif; ?>
		<div class="promo-overlay">
			<?php if($orchid_option['orchid_promo1_title']) : ?>
				<h4><?php echo esc_html($orchid_option['orchid_promo1_title']); ?></h4>
			<?php endif; ?>
		</div>
	</div>
	<?php endif; ?>
	
	<?php if($orchid_option['orchid_promo2_title'] || $orchid_option['orchid_promo2_image']) : ?>
	<div class="promo-item" style="background-image:url(<?php if($orchid_option['orchid_promo2_image']['url']) { echo esc_url($orchid_option['orchid_promo2_image']['url']); } else { echo get_template_directory_uri() . '/images/slider-default.jpg'; } ?>)">
		<?php if($orchid_option['orchid_promo2_url']) : ?><a href="<?php echo esc_url($orchid_option['orchid_promo2_url']); ?>" class="promo-link"></a><?php endif; ?>
		<div class="promo-overlay">
			<?php if($orchid_option['orchid_promo2_title']) : ?>
				<h4><?php echo esc_html($orchid_option['orchid_promo2_title']); ?></h4>
			<?php endif; ?>
		</div>
	</div>
	<?php endif; ?>
	
	<?php if($orchid_option['orchid_promo3_title'] || $orchid_option['orchid_promo3_image']) : ?>
	<div class="promo-item" style="background-image:url(<?php if($orchid_option['orchid_promo3_image']['url']) { echo esc_url($orchid_option['orchid_promo3_image']['url']); } else { echo get_template_directory_uri() . '/images/slider-default.jpg'; } ?>)">
		<?php if($orchid_option['orchid_promo3_url']) : ?><a href="<?php echo esc_url($orchid_option['orchid_promo3_url']); ?>" class="promo-link"></a><?php endif; ?>
		<div class="promo-overlay">
			<?php if($orchid_option['orchid_promo3_title']) : ?>
				<h4><?php echo esc_html($orchid_option['orchid_promo3_title']); ?></h4>
			<?php endif; ?>
		</div>
	</div>
	<?php endif; ?>
	
</div>