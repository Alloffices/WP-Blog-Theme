	
		<!-- END CONTENT -->
		</div>
	
	<!-- END CONTAINER -->
	</div>
	
	<div id="instagram-footer">

		<?php	/* Widgetised Area */	if ( !function_exists( 'dynamic_sidebar' ) || !dynamic_sidebar('Instagram Footer') ) ?>
		
	</div>
	
	<footer id="footer">
		<?php global $orchid_option;?>
		<div class="container clearfix">
			
			<?php if($orchid_option['orchid_footer_share'] != '0') : ?>
			<div id="footer-social">
				
				<?php if($orchid_option['orchid_facebook']) : ?><a href="http://facebook.com/<?php echo esc_html($orchid_option['orchid_facebook']); ?>" target="_blank"><i class="fa fa-facebook"></i></a><?php endif; ?>
				<?php if($orchid_option['orchid_twitter']) : ?><a href="http://twitter.com/<?php echo esc_html($orchid_option['orchid_twitter']); ?>" target="_blank"><i class="fa fa-twitter"></i></a><?php endif; ?>
				<?php if($orchid_option['orchid_instagram']) : ?><a href="http://instagram.com/<?php echo esc_html($orchid_option['orchid_instagram']); ?>" target="_blank"><i class="fa fa-instagram"></i></a><?php endif; ?>
				<?php if($orchid_option['orchid_pinterest']) : ?><a href="http://pinterest.com/<?php echo esc_html($orchid_option['orchid_pinterest']); ?>" target="_blank"><i class="fa fa-pinterest"></i></a><?php endif; ?>
				<?php if($orchid_option['orchid_bloglovin']) : ?><a href="http://bloglovin.com/<?php echo esc_html($orchid_option['orchid_bloglovin']); ?>" target="_blank"><i class="fa fa-heart"></i></a><?php endif; ?>
				<?php if($orchid_option['orchid_google']) : ?><a href="http://plus.google.com/<?php echo esc_html($orchid_option['orchid_google']); ?>" target="_blank"><i class="fa fa-google-plus"></i></a><?php endif; ?>
				<?php if($orchid_option['orchid_tumblr']) : ?><a href="http://<?php echo esc_html($orchid_option['orchid_tumblr']); ?>.tumblr.com/" target="_blank"><i class="fa fa-tumblr"></i></a><?php endif; ?>
				<?php if($orchid_option['orchid_youtube']) : ?><a href="http://youtube.com/<?php echo esc_html($orchid_option['orchid_youtube']); ?>" target="_blank"><i class="fa fa-youtube-play"></i></a><?php endif; ?>
				<?php if($orchid_option['orchid_dribbble']) : ?><a href="http://dribbble.com/<?php echo esc_html($orchid_option['orchid_dribbble']); ?>" target="_blank"><i class="fa fa-dribbble"></i></a><?php endif; ?>
				<?php if($orchid_option['orchid_soundcloud']) : ?><a href="http://soundcloud.com/<?php echo esc_html($orchid_option['orchid_soundcloud']); ?>" target="_blank"><i class="fa fa-soundcloud"></i></a><?php endif; ?>
				<?php if($orchid_option['orchid_vimeo']) : ?><a href="http://vimeo.com/<?php echo esc_html($orchid_option['orchid_vimeo']); ?>" target="_blank"><i class="fa fa-vimeo-square"></i></a><?php endif; ?>
				<?php if($orchid_option['orchid_linkedin']) : ?><a href="<?php echo esc_html($orchid_option['orchid_linkedin']); ?>" target="_blank"><i class="fa fa-linkedin"></i></a><?php endif; ?>
				<?php if($orchid_option['orchid_rss']) : ?><a href="<?php echo esc_url($orchid_option['orchid_rss']); ?>" target="_blank"><i class="fa fa-rss"></i></a><?php endif; ?>
				
			</div>
			<?php endif; ?>
			
			<div id="footer-copyright">

				<p class="copyright"><?php echo wp_kses_post($orchid_option['orchid_footer_copyright']); ?></p>
				
			</div>
			
		</div>
		
	</footer>
	
	<?php wp_footer(); ?>
	
</body>

</html>